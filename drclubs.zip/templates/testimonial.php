<div class="wrap">

    <h1> شورت کد </h1>

    <p>Testimonial Form Shortcode</p>
    <p>
        <code>[testimonial-form]</code>
    </p>

    <p>Testimonial Slideshow Shortcode</p>
    <p>
        <code>[testimonial-slideshow]</code>
    </p>

</div>