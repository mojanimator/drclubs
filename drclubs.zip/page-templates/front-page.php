<?php

/*
  *
  * Template Name: DrClubs Template
  */

get_header(); ?>

    <h1>dr clubs front page</h1>

<?php
get_footer();