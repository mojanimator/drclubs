<?php

/*
  *
  * Template Name: DrClubs Template
  */

get_header(); ?>

    <h1>الگوی دو ستونه</h1>

<?php
get_footer();